from flask import Flask, request, jsonify, send_from_directory, send_file
import subprocess
import os
import json
import logging
import time
import threading
from datetime import datetime

app = Flask(__name__, static_folder='static')
app.logger.setLevel(logging.INFO)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s',
    handlers=[
        logging.FileHandler('process.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Global variable to track scan progress
scan_progress = {
    'status': 'idle',
    'step': '',
    'progress': 0,
    'message': '',
    'results': []
}

@app.route('/')
def index():
    try:
        return send_file('main.html')
    except Exception as e:
        logger.error(f'Error serving main.html: {e}')
        return jsonify({'error': 'Could not load main.html'}), 500

@app.route('/static/<path:filename>')
def static_files(filename):
    try:
        return send_from_directory(app.static_folder, filename)
    except Exception as e:
        logger.error(f'Error serving static file {filename}: {e}')
        return jsonify({'error': f'Could not load static file: {filename}'}), 500

@app.route('/scan', methods=['GET'])
def scan():
    domain = request.args.get('domain')
    if not domain:
        return jsonify({'status': 'error', 'message': 'Domain required'}), 400

    # Check if scan is already running
    if scan_progress['status'] == 'running':
        return jsonify({
            'status': 'running', 
            'message': 'Scan already in progress',
            'progress': scan_progress['progress'],
            'step': scan_progress['step']
        })

    # Start scan in background thread
    thread = threading.Thread(target=run_scan_pipeline, args=(domain,))
    thread.daemon = True
    thread.start()

    return jsonify({
        'status': 'started', 
        'message': f'Ransomware vulnerability scan started for {domain}',
        'domain': domain
    })

@app.route('/scan/progress', methods=['GET'])
def get_scan_progress():
    return jsonify(scan_progress)

@app.route('/scan/results', methods=['GET'])
def get_scan_results():
    try:
        if os.path.exists('url_risk_data.json'):
            with open('url_risk_data.json', 'r', encoding='utf-8') as f:
                results = json.load(f)
            return jsonify({
                'status': 'success',
                'results': results,
                'total_count': len(results)
            })
        else:
            return jsonify({
                'status': 'no_results',
                'message': 'No results available',
                'results': []
            })
    except Exception as e:
        logger.error(f'Error loading results: {e}')
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/vulnerability_reports')
def list_vulnerability_reports():
    """List all available vulnerability reports"""
    try:
        reports_dir = 'vulnerability_reports'
        if not os.path.exists(reports_dir):
            return jsonify({'reports': []})
        
        reports = []
        for filename in os.listdir(reports_dir):
            if filename.endswith('.json'):
                filepath = os.path.join(reports_dir, filename)
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        report_data = json.load(f)
                    
                    reports.append({
                        'filename': filename,
                        'url': report_data.get('url', 'Unknown'),
                        'rrs_score': report_data.get('rrs_score', 0),
                        'risk_level': report_data.get('risk_level', 'Unknown'),
                        'scan_timestamp': report_data.get('scan_timestamp', 'Unknown')
                    })
                except Exception as e:
                    logger.warning(f'Error reading report {filename}: {e}')
        
        # Sort by RRS score (highest first)
        reports.sort(key=lambda x: x['rrs_score'], reverse=True)
        
        return jsonify({'reports': reports})
        
    except Exception as e:
        logger.error(f'Error listing vulnerability reports: {e}')
        return jsonify({'error': str(e)}), 500

@app.route('/vulnerability_reports/<filename>')
def get_vulnerability_report(filename):
    """Get specific vulnerability report"""
    try:
        reports_dir = 'vulnerability_reports'
        filepath = os.path.join(reports_dir, filename)
        
        if not os.path.exists(filepath):
            return jsonify({'error': 'Report not found'}), 404
        
        with open(filepath, 'r', encoding='utf-8') as f:
            report_data = json.load(f)
        
        return jsonify(report_data)
        
    except Exception as e:
        logger.error(f'Error loading vulnerability report: {e}')
        return jsonify({'error': str(e)}), 500

def update_progress(step, progress, message):
    """Update scan progress"""
    global scan_progress
    scan_progress.update({
        'step': step,
        'progress': progress,
        'message': message
    })
    logger.info(f'Progress: {progress}% - {step} - {message}')

def cleanup_old_files():
    """Clean up old result files"""
    files_to_clean = [
        'all_subdomains.txt',
        'active_subdomains_urls.txt',
        'scan_results.csv',
        'scan_results_output.txt',
        'nmap_scan_results.txt',
        'exposed_admin_panels.txt',
        'cve_scan_results.csv',
        'exploit_summary.json',
        'rrs_results.csv',
        'rrs_calculation_breakdown.txt',
        'url_risk_data.json'
    ]
    
    for file in files_to_clean:
        try:
            if os.path.exists(file):
                os.remove(file)
                logger.info(f'Cleaned up old file: {file}')
        except Exception as e:
            logger.warning(f'Could not remove file {file}: {e}')

def run_script_with_timeout(script_name, args=None, timeout=300):
    """Run a script with timeout and error handling"""
    try:
        cmd = ['python', script_name]
        if args:
            cmd.extend(args)
        
        logger.info(f'Executing: {" ".join(cmd)}')
        
        result = subprocess.run(
            cmd, 
            capture_output=True, 
            text=True, 
            timeout=timeout,
            encoding='utf-8'
        )
        
        if result.stdout:
            logger.info(f'{script_name} stdout: {result.stdout}')
        if result.stderr:
            logger.warning(f'{script_name} stderr: {result.stderr}')
        
        if result.returncode != 0:
            logger.error(f'{script_name} failed with return code {result.returncode}')
            return False, f'{script_name} failed: {result.stderr}'
        
        return True, f'{script_name} completed successfully'
        
    except subprocess.TimeoutExpired:
        error_msg = f'{script_name} timed out after {timeout} seconds'
        logger.error(error_msg)
        return False, error_msg
    except Exception as e:
        error_msg = f'{script_name} execution error: {str(e)}'
        logger.error(error_msg)
        return False, error_msg

def run_scan_pipeline(domain):
    """Run the complete vulnerability scanning pipeline"""
    global scan_progress
    
    try:
        scan_progress['status'] = 'running'
        start_time = time.time()
        
        # Step 1: Cleanup old files
        update_progress('cleanup', 5, 'Cleaning up old files...')
        cleanup_old_files()
        
        # Step 2: Subdomain discovery and verification
        update_progress('subdomain_discovery', 15, 'Discovering subdomains...')
        success, message = run_script_with_timeout('sub.py', [domain], timeout=600)
        if not success:
            scan_progress.update({'status': 'error', 'message': message})
            return
        
        # Check if we have active subdomains
        if not os.path.exists('active_subdomains_urls.txt') or os.path.getsize('active_subdomains_urls.txt') == 0:
            error_msg = 'No active subdomains found'
            scan_progress.update({'status': 'error', 'message': error_msg})
            return
        
        # Step 3: Port scanning
        update_progress('port_scanning', 30, 'Scanning for open ports...')
        success, message = run_script_with_timeout('port.py', timeout=900)
        if not success:
            logger.warning(f'Port scanning warning: {message}')
            # Continue even if port scanning fails partially
        
        # Step 4: Technology and security scanning
        update_progress('technology_scanning', 45, 'Analyzing technologies and security features...')
        success, message = run_script_with_timeout('other.py', timeout=1200)
        if not success:
            scan_progress.update({'status': 'error', 'message': message})
            return
        
        # Step 5: Admin panel detection
        update_progress('admin_panel_detection', 60, 'Checking for exposed admin panels...')
        success, message = run_script_with_timeout('check_admin_panel.py', timeout=900)
        if not success:
            logger.warning(f'Admin panel detection warning: {message}')
            # Continue even if admin panel detection fails
        
        # Step 6: CVE and vulnerability analysis
        update_progress('vulnerability_analysis', 75, 'Analyzing vulnerabilities...')
        success, message = run_script_with_timeout('cve.py', timeout=1800)
        if not success:
            logger.warning(f'CVE analysis warning: {message}')
            # Continue even if CVE analysis fails partially

        # Step 6b: Exploit check (run cve_exploit_checker.py after cve.py)
        update_progress('exploit_check', 80, 'Checking for public exploits...')
        success, message = run_script_with_timeout('cve_exploit_checker.py', ["-i", "cve_scan_results.csv", "-o", "exploit_results.json"], timeout=900)
        if not success:
            logger.warning(f'Exploit check warning: {message}')
            # Continue even if exploit check fails partially

        # Step 7: Risk score calculation
        update_progress('risk_calculation', 90, 'Calculating ransomware risk scores...')
        success, message = run_script_with_timeout('RRS.py', timeout=300)
        if not success:
            scan_progress.update({'status': 'error', 'message': message})
            return
        
        # Step 8: Load and validate results
        update_progress('finalizing', 95, 'Finalizing results...')
        
        try:
            with open('url_risk_data.json', 'r', encoding='utf-8') as f:
                results = json.load(f)
            
            scan_progress.update({
                'status': 'completed',
                'step': 'complete',
                'progress': 100,
                'message': f'Scan completed successfully. Found {len(results)} URLs with significant risk.',
                'results': results,
                'execution_time': round(time.time() - start_time, 2),
                'completion_time': datetime.now().isoformat()
            })
            
            logger.info(f'Scan completed successfully for {domain}. Found {len(results)} high-risk URLs.')
            
        except FileNotFoundError:
            scan_progress.update({
                'status': 'completed',
                'step': 'complete', 
                'progress': 100,
                'message': 'Scan completed but no significant risks were found.',
                'results': [],
                'execution_time': round(time.time() - start_time, 2),
                'completion_time': datetime.now().isoformat()
            })
            
            logger.info(f'Scan completed for {domain} with no significant risks found.')
        
    except Exception as e:
        error_msg = f'Scan pipeline error: {str(e)}'
        logger.error(error_msg)
        scan_progress.update({
            'status': 'error',
            'message': error_msg,
            'execution_time': round(time.time() - start_time, 2) if 'start_time' in locals() else 0
        })

@app.route('/scan/stop', methods=['POST'])
def stop_scan():
    """Stop current scan"""
    global scan_progress
    scan_progress.update({
        'status': 'stopped',
        'message': 'Scan stopped by user'
    })
    return jsonify({'status': 'stopped', 'message': 'Scan stopped'})

@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('vulnerability_reports', exist_ok=True)
    os.makedirs('static', exist_ok=True)
    
    print("=" * 60)
    print("Ransomware Vulnerability Risk Assessment Tool")
    print("=" * 60)
    print("Starting Flask application...")
    print("Access the web interface at: http://localhost:5000")
    print("API endpoints:")
    print("  GET  /scan?domain=<domain>     - Start vulnerability scan")
    print("  GET  /scan/progress           - Get scan progress")
    print("  GET  /scan/results            - Get scan results")
    print("  GET  /vulnerability_reports   - List vulnerability reports")
    print("  POST /scan/stop               - Stop current scan")
    print("=" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)