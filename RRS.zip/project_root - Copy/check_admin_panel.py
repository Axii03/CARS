import argparse
import requests
import re
import urllib.parse
import urllib3
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Comprehensive list of admin panel paths
admin_paths = [
    '/admin', '/administrator', '/admin/login', '/adminpanel', '/admin_area', '/cpanel', '/backend',
    '/admin1', '/admin2', '/admin123', '/login', '/useradmin', '/manage', '/dashboard', '/adm', 
    '/admin-console', '/admincontrol', '/admin_home', '/admin/account', '/admin/index', '/admin/main', 
    '/adminsecure', '/systemadmin', '/adminsite', '/adminportal', '/admininterface', '/admin_section', 
    '/admincenter', '/adminaccess', '/root', '/superuser', '/moderator', '/webadmin', '/controlpanel', 
    '/memberadmin', '/adminlogin', '/adminsignin', '/wp-admin', '/wp-login.php', '/admin.php', 
    '/admin.html', '/admin.asp', '/admin.aspx', '/admin.jsp', '/phpmyadmin', '/phpMyAdmin',
    '/myadmin', '/mysql', '/dbadmin', '/database', '/db', '/webdb', '/configuration', '/config',
    '/settings', '/setup', '/install', '/installation', '/panel', '/panels', '/control',
    '/console', '/manager', '/management', '/supervisor', '/staff', '/employee', '/user',
    '/users', '/account', '/accounts', '/profile', '/profiles', '/secure', '/security',
    '/protected', '/private', '/restricted', '/internal', '/intranet', '/extranet'
]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
}

def check_url(url, path, timeout=10):
    """Check if admin panel exists at given URL + path"""
    try:
        # Parse and clean the URL
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname:
            logger.warning(f"Skipping invalid URL: {url}")
            return None
            
        # Build clean base URL
        clean_url = f"{parsed.scheme}://{parsed.hostname}"
        if parsed.port:
            clean_url += f":{parsed.port}"
            
        # Add path
        if not path.startswith('/'):
            path = '/' + path
        test_url = clean_url + path

        # Determine SSL verification
        verify_ssl = True
        if parsed.scheme == 'https' and re.match(r'^\d+\.\d+\.\d+\.\d+$', parsed.hostname):
            verify_ssl = False

        # Make request
        response = requests.get(
            test_url, 
            headers=HEADERS, 
            timeout=timeout, 
            allow_redirects=True, 
            verify=verify_ssl
        )

        # Check for admin panel indicators
        if response.status_code == 200:
            content = response.text.lower()
            
            # Look for admin panel indicators in content
            admin_indicators = [
                'admin', 'administrator', 'login', 'password', 'username', 'dashboard',
                'control panel', 'management', 'configuration', 'settings', 'database',
                'phpmyadmin', 'cpanel', 'plesk', 'webmin', 'directadmin'
            ]
            
            # Check title and content for admin indicators
            title_match = re.search(r'<title>(.*?)</title>', content, re.IGNORECASE)
            title = title_match.group(1) if title_match else ""
            
            # Strong indicators for admin panels
            strong_indicators = [
                'sign in', 'log in', 'login', 'administrator', 'admin panel',
                'control panel', 'dashboard', 'management console'
            ]
            
            # Check for login forms
            has_login_form = bool(re.search(r'<form.*?(login|signin|password)', content, re.IGNORECASE))
            has_password_field = bool(re.search(r'<input.*?type=["\']password["\']', content, re.IGNORECASE))
            
            # Score the likelihood this is an admin panel
            score = 0
            
            # Title indicators
            for indicator in strong_indicators:
                if indicator in title.lower():
                    score += 3
                    
            # Content indicators  
            for indicator in admin_indicators:
                if indicator in content:
                    score += 1
                    
            # Form indicators
            if has_login_form:
                score += 2
            if has_password_field:
                score += 2
                
            # URL path indicators
            if any(admin_word in path.lower() for admin_word in ['admin', 'login', 'panel', 'manage']):
                score += 1

            # Return if score is high enough (likely admin panel)
            if score >= 3:
                logger.info(f"Admin panel found: {test_url} (score: {score})")
                return {
                    'url': test_url,
                    'title': title.strip()[:100] if title else 'No title',
                    'score': score,
                    'has_login_form': has_login_form,
                    'status_code': response.status_code
                }
                
        return None
        
    except requests.exceptions.Timeout:
        logger.debug(f"Timeout for {test_url}")
        return None
    except requests.exceptions.ConnectionError:
        logger.debug(f"Connection error for {test_url}")
        return None
    except Exception as e:
        logger.debug(f"Error checking {test_url}: {e}")
        return None

def load_urls_from_file(filename):
    """Load and parse URLs from file"""
    urls = []
    
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                    
                # Handle different formats
                if ',' in line:
                    # Format: url,ip
                    url = line.split(',')[0].strip()
                else:
                    url = line
                    
                # Ensure URL has scheme
                if not url.startswith(('http://', 'https://')):
                    # Try https first, then http
                    urls.append(f"https://{url}")
                    urls.append(f"http://{url}")
                else:
                    urls.append(url)
                    
        # Remove duplicates while preserving order
        seen = set()
        unique_urls = []
        for url in urls:
            if url not in seen:
                seen.add(url)
                unique_urls.append(url)
                
        logger.info(f"Loaded {len(unique_urls)} unique URLs from {filename}")
        return unique_urls
        
    except FileNotFoundError:
        logger.error(f"File not found: {filename}")
        print(f"[!] File not found: {filename}")
        return []
    except Exception as e:
        logger.error(f"Error reading file {filename}: {e}")
        print(f"[!] Error reading file: {e}")
        return []

def check_admin_panels(filename, output_file='exposed_admin_panels.txt'):
    """Main function to check for admin panels"""
    print(f"[+] Starting admin panel detection...")
    
    urls = load_urls_from_file(filename)
    if not urls:
        print("[!] No URLs to check")
        return

    print(f"[+] Checking {len(urls)} URLs against {len(admin_paths)} admin paths")
    
    found_panels = []
    total_checks = len(urls) * len(admin_paths)
    completed_checks = 0
    
    try:
        with ThreadPoolExecutor(max_workers=20) as executor:
            # Submit all URL+path combinations
            futures = []
            for url in urls:
                for path in admin_paths:
                    future = executor.submit(check_url, url, path)
                    futures.append(future)
            
            # Process results as they complete
            for future in as_completed(futures):
                completed_checks += 1
                if completed_checks % 100 == 0:
                    progress = (completed_checks / total_checks) * 100
                    print(f"[+] Progress: {completed_checks}/{total_checks} ({progress:.1f}%)")
                
                try:
                    result = future.result()
                    if result:
                        print(f"[+] Admin panel found: {result['url']}")
                        found_panels.append(result)
                except Exception as e:
                    logger.debug(f"Future execution error: {e}")
                    
    except KeyboardInterrupt:
        print("\n[!] Scan interrupted by user")
    except Exception as e:
        logger.error(f"Error during scanning: {e}")
        print(f"[!] Error during scanning: {e}")

    # Save results
    if found_panels:
        try:
            with open(output_file, 'w', encoding='utf-8') as out:
                for panel in found_panels:
                    # Extract base domain for compatibility with RRS.py
                    parsed = urllib.parse.urlparse(panel['url'])
                    base_domain = parsed.hostname
                    if parsed.port:
                        base_domain += f":{parsed.port}"
                    
                    # Format: full_url,base_domain
                    out.write(f"{panel['url']},{base_domain}\n")
                    
            print(f"[+] Found {len(found_panels)} admin panels")
            print(f"[+] Results saved to {output_file}")
            
            # Display summary
            print(f"\n[+] Admin Panel Summary:")
            print("-" * 60)
            for panel in found_panels:
                print(f"  {panel['url']}")
                print(f"    Title: {panel['title']}")
                print(f"    Score: {panel['score']}")
                print(f"    Has Login Form: {panel['has_login_form']}")
                print()
                
        except Exception as e:
            logger.error(f"Error writing output file: {e}")
            print(f"[!] Error saving results: {e}")
    else:
        print("[+] No admin panels found")
        # Create empty file to prevent errors in downstream scripts
        try:
            with open(output_file, 'w') as out:
                pass
        except Exception as e:
            logger.error(f"Error creating empty output file: {e}")

def main():
    print("[+] Admin Panel Detection Tool")
    
    parser = argparse.ArgumentParser(description="Check for exposed admin panels on subdomains.")
    parser.add_argument("-i", "--input", type=str, default="active_subdomains_urls.txt", 
                       help="Input file with subdomain URLs")
    parser.add_argument("-o", "--output", type=str, default="exposed_admin_panels.txt", 
                       help="Output file for found admin panels")
    args = parser.parse_args()
    
    check_admin_panels(args.input, args.output)

if __name__ == "__main__":
    main()