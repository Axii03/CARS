let chartInstance = null;

async function scan() {
  const domain = document.getElementById('domain').value.trim();
  const container = document.getElementById('results-container');
  const chartContainer = document.getElementById('riskChart');
  const rawJsonOutput = document.getElementById('raw-json-output');

  if (!domain) {
    container.innerHTML = `<div class="error">Please enter a domain.</div>`;
    rawJsonOutput.textContent = '';
    return;
  }

  container.innerHTML = `<div class="loading">🔍 Scanning <b>${domain}</b>...</div>`;
  rawJsonOutput.textContent = '';
  if (chartInstance) {
    chartInstance.destroy();
    chartInstance = null;
  }

  try {
    // Start scan
    const response = await fetch(`/scan?domain=${encodeURIComponent(domain)}`);
    const resultObj = await response.json();
    if (!response.ok || (resultObj.status !== 'started' && resultObj.status !== 'running')) {
      throw new Error(resultObj.message || "Scan failed or backend error.");
    }
    // Poll for progress and results
    pollScanProgress(domain, container, rawJsonOutput, chartContainer);
  } catch (error) {
    container.innerHTML = `<div class="error">Error: ${error.message}</div>`;
    rawJsonOutput.textContent = '';
  }
async function pollScanProgress(domain, container, rawJsonOutput, chartContainer) {
  let pollInterval = 3000;
  let maxWait = 60 * 20 * 1000; // 20 minutes
  let waited = 0;
  container.innerHTML = `<div class="loading">⏳ Scan in progress for <b>${domain}</b>... Please wait.</div>`;
  while (waited < maxWait) {
    try {
      const progressResp = await fetch('/scan/progress');
      const progressObj = await progressResp.json();
      if (progressObj.status === 'completed') {
        // Fetch results
        const resultsResp = await fetch('/scan/results');
        const resultsObj = await resultsResp.json();
        const results = resultsObj.results;
        if (!results || results.length === 0) {
          container.innerHTML = `<div class="error">No results found for <b>${domain}</b>.</div>`;
          rawJsonOutput.textContent = '';
          return;
        }
        container.innerHTML = `
          <h2>Scan Results for <span style='color:#2563eb'>${domain}</span></h2>
          <div class="results-grid">
            ${results.map(entry => renderCard(entry)).join('')}
          </div>
        `;
        rawJsonOutput.textContent = JSON.stringify(results, null, 2);
        updateChart(results);
        window.latestScanResults = results;
        return;
      } else if (progressObj.status === 'error') {
        container.innerHTML = `<div class="error">Error: ${progressObj.message || 'Scan failed.'}</div>`;
        rawJsonOutput.textContent = '';
        return;
      } else {
        // Show progress
        container.innerHTML = `<div class="loading">⏳ ${progressObj.message || 'Scan in progress...'} (${progressObj.progress || 0}%)</div>`;
      }
    } catch (e) {
      container.innerHTML = `<div class="error">Error polling scan progress: ${e.message}</div>`;
      rawJsonOutput.textContent = '';
      return;
    }
    await new Promise(res => setTimeout(res, pollInterval));
    waited += pollInterval;
  }
  container.innerHTML = `<div class="error">Scan timed out. Please try again.</div>`;
  rawJsonOutput.textContent = '';
}
}

function renderCard(entry) {
  const riskClass = entry.risk_level ? `risk-${entry.risk_level.toLowerCase()}` : '';
  return `
    <div class="result-card ${riskClass}">
      <h3>${entry.url ? entry.url : 'Unknown URL'}</h3>
      <p><b>Risk Score:</b> <span>${entry.rrs_score !== undefined ? entry.rrs_score : 'N/A'}</span></p>
      <p><b>Risk Level:</b> <span class="${riskClass}">${entry.risk_level || 'N/A'}</span></p>
      <button onclick='showBreakdown(${JSON.stringify(entry)})'>Show Details</button>
    </div>
  `;
}

function showBreakdown(entry) {
  let details = `<b>URL:</b> ${entry.url || 'N/A'}<br>`;
  details += `<b>Risk Score:</b> ${entry.rrs_score !== undefined ? entry.rrs_score : 'N/A'}<br>`;
  details += `<b>Risk Level:</b> ${entry.risk_level || 'N/A'}<br>`;
  if (entry.calculation_details) {
    const calc = entry.calculation_details;
    if (calc.ports) {
      details += `<b>Open Ports:</b> ${calc.ports.found && calc.ports.found.length ? calc.ports.found.join(', ') : 'None'}<br>`;
    }
    if (calc.vulnerabilities) {
      details += `<b>Vulnerabilities:</b> ${calc.vulnerabilities.found || 0}<br>`;
      if (calc.vulnerabilities.details && calc.vulnerabilities.details.length) {
        details += `<ul>`;
        for (const vuln of calc.vulnerabilities.details) {
          details += `<li>CVE: ${vuln.cve_id}, Type: ${vuln.type}, Severity: ${vuln.severity}, Exploit: ${vuln.has_exploit ? 'Yes' : 'No'}</li>`;
        }
        details += `</ul>`;
      }
    }
    if (calc.admin_panel) {
      details += `<b>Admin Panel Exposed:</b> ${calc.admin_panel.exposed ? 'Yes' : 'No'}<br>`;
    }
    if (calc.security_controls) {
      details += `<b>WAF:</b> ${calc.security_controls.waf.present ? 'Yes' : 'No'}<br>`;
      details += `<b>SSL:</b> ${calc.security_controls.ssl ? 'Valid' : 'Invalid/Missing'}<br>`;
    }
  }
  details += `<b>Formula:</b> ${entry.calculation_details && entry.calculation_details.formula_breakdown ? entry.calculation_details.formula_breakdown.rrs_calculation : 'N/A'}<br>`;
  const modal = document.createElement('div');
  modal.style.position = 'fixed';
  modal.style.top = '0';
  modal.style.left = '0';
  modal.style.width = '100vw';
  modal.style.height = '100vh';
  modal.style.background = 'rgba(0,0,0,0.4)';
  modal.style.display = 'flex';
  modal.style.alignItems = 'center';
  modal.style.justifyContent = 'center';
  modal.innerHTML = `<div style='background:#fff;padding:24px;border-radius:8px;max-width:500px;box-shadow:0 2px 12px rgba(0,0,0,0.2);'>${details}<br><button onclick='this.parentElement.parentElement.remove()'>Close</button></div>`;
  document.body.appendChild(modal);
}

function updateChart(results) {
  const ctx = document.getElementById('riskChart').getContext('2d');
  const labels = results.map(r => r.url || 'Unknown');
  const scores = results.map(r => r.rrs_score || 0);
  const bgColors = results.map(r => {
    if (r.risk_level === 'HIGH') return 'rgba(255, 99, 132, 0.6)';
    if (r.risk_level === 'MEDIUM') return 'rgba(255, 206, 86, 0.6)';
    return 'rgba(75, 192, 192, 0.6)';
  });

  if (chartInstance) chartInstance.destroy();
  chartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Risk Score',
        data: scores,
        backgroundColor: bgColors,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: { beginAtZero: true }
      }
    }
  });
}

function exportJson() {
  const results = window.latestScanResults;
  if (!results || !results.length) return alert("No results to export.");
  const blob = new Blob([JSON.stringify(results, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = "scan_results.json";
  a.click();
  URL.revokeObjectURL(url);
}

function exportCsv() {
  const results = window.latestScanResults;
  if (!results || !results.length) return alert("No results to export.");
  const header = ["url", "rrs_score", "risk_level"];
  const rows = results.map(entry => [
    entry.url || "",
    entry.rrs_score !== undefined ? entry.rrs_score : "",
    entry.risk_level || ""
  ]);
  let csv = header.join(",") + "\n" + rows.map(r => r.join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = "scan_results.csv";
  a.click();
  URL.revokeObjectURL(url);
}
