import subprocess
import sys
import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

def run_amass(domain, output_file, resolvers_file=None, dns_qps=100, timeout=5, wordlist=None):
    try:
        print(f"[*] Running Amass (passive) for domain: {domain}")
        cmd = ["amass", "enum", "-passive", "-d", domain, "-o", output_file]
        if resolvers_file and os.path.isfile(resolvers_file):
            cmd.extend(["-rf", resolvers_file])
        cmd.extend(["-dns-qps", str(dns_qps)])
        cmd.extend(["-timeout", str(timeout)])
        if wordlist and os.path.isfile(wordlist):
            cmd.extend(["-w", wordlist])
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        print("[*] Amass passive scan completed.")
    except subprocess.CalledProcessError as e:
        print(f"[!] Amass failed: {e.stderr}")
        sys.exit(1)
    except FileNotFoundError:
        print("[!] Amass not found. Please install Amass and ensure it's in your PATH.")
        sys.exit(1)

def check_subdomain_httpx(url):
    try:
        result = subprocess.run(
            ["httpx", "-silent", "-no-color", "-timeout", "5", "-status-code", "-title", "-u", url],
            capture_output=True,
            text=True,
            check=True,
            encoding="utf-8"  # <-- Add this line
        )
        if result.stdout.strip():
            return result.stdout.strip().split()[0]
    except subprocess.CalledProcessError:
        return None
    except UnicodeDecodeError as e:
        print(f"[!] Unicode decode error for {url}: {e}")
        return None
    return None

def run_httpx_parallel(input_file, output_file):
    print(f"[*] Checking active subdomains with httpx in parallel...")
    with open(input_file, "r", encoding="utf-8") as infile:
        urls = []
        for line in infile:
            match = re.match(r'^(https?://[^\s]+)', line.strip())
            if match:
                urls.append(match.group(1))
    active = set()
    with ThreadPoolExecutor() as executor:
        future_to_url = {executor.submit(check_subdomain_httpx, url): url for url in urls}
        for future in as_completed(future_to_url):
            result = future.result()
            if result:
                active.add(result)
    with open(output_file, "w", encoding="utf-8") as out:
        for url in sorted(active):
            out.write(url + "\n")
    print(f"[*] Active subdomains saved to {output_file}")

def filter_urls_from_file(input_file, output_file):
    seen = set()
    with open(input_file, "r", encoding="utf-8") as infile, open(output_file, "w", encoding="utf-8") as outfile:
        for line in infile:
            match = re.match(r'^(https?://[^\s]+)', line.strip())
            if match:
                url = match.group(1)
                if url not in seen:
                    outfile.write(url + "\n")
                    seen.add(url)

def main():
    if len(sys.argv) < 2:
        print(f"Usage: python {os.path.basename(__file__)} <domain|all_subdomains_urls.txt> [resolvers.txt] [wordlist.txt]")
        sys.exit(1)

    arg1 = sys.argv[1]
    resolvers_file = sys.argv[2] if len(sys.argv) > 2 else None
    wordlist = sys.argv[3] if len(sys.argv) > 3 else None

    all_subdomains_file = "all_subdomains.txt"
    all_subdomains_urls_file = "all_subdomains_urls.txt"
    filtered_urls_file = "filtered_urls.txt"
    active_subdomains_urls_file = "active_subdomains_urls.txt"

    try:
        if os.path.isfile(arg1):
            print(f"[*] Filtering URLs from {arg1}")
            filter_urls_from_file(arg1, filtered_urls_file)
            run_httpx_parallel(filtered_urls_file, active_subdomains_urls_file)
        else:
            domain = arg1
            run_amass(domain, all_subdomains_file, resolvers_file=resolvers_file, wordlist=wordlist)
            urls = set()
            with open(all_subdomains_file, "r", encoding="utf-8") as infile:
                for line in infile:
                    sub = line.strip()
                    if sub:
                        urls.add(f"http://{sub}")
                        urls.add(f"https://{sub}")
            with open(all_subdomains_urls_file, "w", encoding="utf-8") as outfile:
                for url in sorted(urls):
                    outfile.write(url + "\n")

            run_httpx_parallel(all_subdomains_urls_file, active_subdomains_urls_file)
    except Exception as e:
        print(f"[!] Error in main: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()